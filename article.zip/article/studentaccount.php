<?php
session_start();
include("dbconnection.php");
if(!isset($_SESSION['studentid']))
{
	echo "<script>window.location='studentlogin.php';</script>";
}
include("headers.php");

$sqlpatient = "SELECT * FROM student WHERE studentid='$_SESSION[studentid]' ";
$qsqlpatient = mysqli_query($con,$sqlstudent);
$rspatient = mysqli_fetch_array($qsqlstudent);

?>
<div class="wrapper col2">
  <div id="breadcrumb">
    <ul>
      
      <li  class="first">Student Account</li>
    </ul>
  </div>
</div>
<div class="wrapper col4">
  <div id="container">
    <h1 style="color:rgba(0,4,70,1.00)"> &nbsp; Database Records</h1>
    <h1>Number of Article Records :
    <?php
	$sql = "SELECT * FROM article ";
	$qsql = mysqli_query($con,$sql);
	echo mysqli_num_rows($qsql);
	?>
    </h1>
  </div>
</div>

    <div class="clear"></div>
  </div>
</div>
<?php
include("footers.php");
?>