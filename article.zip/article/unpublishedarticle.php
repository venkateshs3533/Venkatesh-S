<?php
session_start();
include("headers.php");
include("dbconnection.php");
if(isset($_GET[delid]))
{
	$sql ="DELETE FROM article WHERE article_id='$_GET[delid]'";
	$qsql=mysqli_query($con,$sql);
	if(mysqli_affected_rows($con) == 1)
	{
		echo "<script>alert('article deleted successfully..');</script>";
	}
}
?>
<?php
if(isset($_GET[editid]))
	{
			$sql ="UPDATE article SET articlename='$_POST[articlename]',articlecontent='$_POST[articlecontent]',articleurl='$_POST[articleurl]',pdf=[pdf] WHERE article_id='$_GET[editid]'";
      $qsql=mysqli_query($con,$sql);
      if($qsql = mysqli_query($con,$sql))
		{
			echo "<script>alert('student record updated successfully...');</script>";
		}

	}


?>

<div class="wrapper col2">
  <div id="breadcrumb">
    <ul>
      <li class="first">UNPUBLISHED ARTICLES LIST</li></ul>
  </div>
</div>
<div class="wrapper col4">
  <div id="container">

<section class="container">
<h2>Search Article - <input type="search" class="light-table-filter" data-table="order-table" placeholder="Filter" /></h2>


	<table class="order-table">
      <thead>
        <tr>
          <th width="10%" height="36"><div align="center">Article ID</div></th>
          <th width="20%"><div align="center">Article Name</div></th>
          <th width="32%"><div align="center">Article Content</div></th>    
          <th width="20%"><div align="center">Article Url</div></th>
          <th width="14%"><div align="center">ACTION</div></th>
        </tr>
        </thead>
      <tbody>
   <?php
        $url = $_POST["articleurl"];
		$sql ="SELECT * FROM `article` WHERE status= 0";
		$qsql = mysqli_query($con,$sql);
		while($rs = mysqli_fetch_array($qsql))
		{
        
        echo "<tr>
        <td><div align=center>&nbsp;$rs[article_id]</div></td>
        <td><div align=left>$rs[articlename]</div></td>
        <td><div align=left>$rs[articlecontent]</div></td>
        <td><div align=left><a href=$rs[articleurl]>$rs[articleurl]</div></a></td>
        <td align='center'>Status - $rs[status] <br>";
        if(isset($_SESSION[adminid]))
        {
		  echo "<a href='addarticle.php?editid=$rs[article_id]'>Edit</a> | <a href='unpublishedarticle.php?delid=$rs[article_id]'>Delete</a>
      <br><a href=download.php?file=$rs[pdf]>Download</a>";
        }
        if(isset($_SESSION[reviewerid]))
        {
		  echo "<a href='addarticle.php?editid=$rs[article_id]'>Edit</a> | <a href=download.php?file=$rs[pdf]>Download</a>";
        }
        if(isset($_SESSION[studentid]))
        {
		  echo "<a href=download.php?file=$rs[pdf]>Download</a>";
        }
       echo"<hr></td></tr>";
         
		}
		?>   
      </tbody>
    </table>
</section>
    <p>&nbsp;</p>
  </div>
</div>
</div>
 <div class="clear"></div>
  </div>
</div>

<?php
include("footers.php");
?>