<?php
session_start();
include("headers.php");
include("dbconnection.php");
if(isset($_GET[delid]))
{
	$sql ="DELETE FROM reviewer WHERE reviewerid='$_GET[delid]'";
	$qsql=mysqli_query($con,$sql);
	if(mysqli_affected_rows($con) == 1)
	{
		echo "<script>alert('reviewer record deleted successfully..');</script>";
	}
}
?>
<?php
if(isset($_GET[editid]))
	{
		$sql ="UPDATE reviewer SET reviewername='$_POST[reviewername]',mobileno='$_POST[mobilenumber]',departmentid='$_POST[select3]',loginid='$_POST[loginid]',password='$_POST[password]',status='$_POST[select]',education='$_POST[education]',experience='$_POST[experience]' WHERE reviewerid='$_GET[editid]'";
		$qsql=mysqli_query($con,$sql);
      if($qsql = mysqli_query($con,$sql))
		{
			echo "<script>alert('Reviewer record updated successfully...');</script>";
		}
	
	}
	?>

<div class="wrapper col2">
  <div id="breadcrumb">View  Reviewer  </div>
</div>
<div class="wrapper col4">
  <div id="container">
 
<section class="container">
<h2>Search Student - <input type="search" class="light-table-filter" data-table="order-table" placeholder="Filter" /></h2>



	<table class="order-table">
      <thead>
   
    <table style="width:100%;" border="3">
      <thead>
      <tr>

        <th width="12%" height="36"><div align="center">Reviewer Name</div></th>
          <th width="12%"><div align="center">Mobile Number</div></th>
          <th width="12%"><div align="center">Department</div></th>    
          <th width="12%"><div align="center">Login ID</div></th>
          <th width="12%"><div align="center">Education</div></th>
          <th width="12%"><div align="center">Experience</div></th>
          <th width="12%"><div align="center">Status</div></th>
          <th width="12%"><div align="center">Action</div></th>
       </tr>
       </thead>
       <tbody>
          <?php
		$sql ="SELECT * FROM reviewer";
		$qsql = mysqli_query($con,$sql);
		while($rs = mysqli_fetch_array($qsql))
		{
			
			$sqldept = "SELECT * FROM department WHERE departmentid='$rs[departmentid]'";
			$qsqldept = mysqli_query($con,$sqldept);
			$rsdept = mysqli_fetch_array($qsqldept);
        echo "<tr>
          <td>&nbsp;$rs[reviewername]</td>
          <td>&nbsp;$rs[mobileno]</td>
		   <td>&nbsp;$rsdept[departmentname]</td>
			<td>&nbsp;$rs[loginid]</td>
			 <td>&nbsp;$rs[education]</td>
			<td>&nbsp;$rs[experience]</td>
          <td>$rs[status]</td>
           <td>&nbsp;
		   <a href='reviewer.php?editid=$rs[reviewerid]'>Edit</a> | <a href='viewreviewer.php?delid=$rs[reviewerid]'>Delete</a> </td>
        </tr>";
        
		}
		?>      
    </tbody>
    </table>
    </section>
    <p>&nbsp;</p>
  </div>
</div>
</div>
 <div class="clear"></div>
  </div>
</div>
<?php
include("footers.php");
?>