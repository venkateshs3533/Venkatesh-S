<?php
session_start();
if(!isset($_SESSION['reviewerid']))
{
	echo "<script>window.location='reviewerlogin.php';</script>";
}
include("headers.php");
?>
<div class="wrapper col2">
  <div id="breadcrumb">
    <ul>
      <li class="first">Reviewer Account</li>
    </ul>
  </div>
</div>
<div class="wrapper col4">
  <div id="container">
    
    <h1 style="color:rgba(0,4,70,1.00)"> &nbsp; Database Records</h1>
    <h1>Number of Student Records : 
    <?php
	$sql = "SELECT * FROM student WHERE status='Active'";
	$qsql = mysqli_query($con,$sql);
	echo mysqli_num_rows($qsql);
	?>
    </h1> 
    <h1>Number of Article Records :
    <?php
	$sql = "SELECT * FROM article ";
	$qsql = mysqli_query($con,$sql);
	echo mysqli_num_rows($qsql);
	?>
    </h1>
   </div>
</div>

    <div class="clear"></div>
  </div>
</div>
<?php
include("footers.php");
?>