<?php
include("header.php");
?>
<div class="wrapper col2">
  <div id="gallery">
    <ul>
      <li class="placeholder" style="background-image:url(images/demo/.jpg);">Image Holder</li>
      <li><a class="swap" style="background-image:url(images/demo/.jpg);" href="#gallery"><strong>Services</strong><span><img src="images/demo/.jpg" alt="" /></span></a></li>
      <li><a class="swap" style="background-image:url(images/demo/.jpg);" href="#gallery"><strong>Products</strong><span><img src="images/demo/.jpg" alt="" /></span></a></li>
      <li class="last"><a class="swap" style="background-image:url(images/demo/img2.jpg);" href="#gallery"><strong>Company</strong><span><img src="images/demo/.jpg" alt="" /></span></a></li>
    </ul>
    <div class="clear"></div>
  </div>
</div>
<div class="wrapper col4">
  <div id="container">
    <div id="content">
      <h1>About Knowledge Repository</h1>
      <p align="justify">..</p>
      <p align="justify">..</p>
      <p align="justify">... </p>
      <div class="homecontent">
        <ul>
          <li>
           <h2>knowledge Repository</h2>
            <p class="imgholder"><img src="images/" alt="" style="width:286px;height:100px;"  /></p>
          </li>
          <li class="last">
            <h2>24X7 services</h2>
            <p class="imgholder"><img src="images/24x7.png" alt="" style="width:286px;height:100px;"   /></p>
          </li>
        </ul>
        <div class="clear"></div>
      </div>
      <p><strong>NIE message:</strong><br />
     .....</p>
    </div>
    <div id="column">
      <div id="featured">
        <ul>
          <li>
            <h2>Our Services</h2>
            <p class="imgholder"><img src="images/Image.png" alt="" style="width:240px;height:90px;" /></p>
          </li>
          <li role="menuitem">...........</li>
          <li aria-haspopup="Sidebar1_Menu2:submenu:36" role="menuitem">...........</li>
          <li role="menuitem">...........</li>
          <li role="menuitem">...........</li>
          <li role="menuitem">...........</li>
          <li role="menuitem">...........</li>
          <li role="menuitem">...........</li>
          <li role="menuitem"><a href=""  tabindex="-1">...........</a></li>
          <li role="menuitem"><a href=""  tabindex="-1">...........</a></li>
        </ul>
      </div>
    </div>
    <div class="clear"></div>
  </div>
</div>
<?php
include("footer.php");
?>