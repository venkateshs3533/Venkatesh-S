<?php
session_start();
include("headers.php");
include("dbconnection.php");

$fn = $_FILES['dp']['name'];
$tm = $_FILES['dp']['tmp_name'];
move_uploaded_file($tm, "files/".$fn);

if(isset($_POST[submit]))
{
	if(isset($_GET[editid]))
	{
		
		$sql ="UPDATE article SET articlename='$_POST[articlename]',articlecontent='$_POST[articlecontent]',articleurl='$_POST[articleurl]',pdf='$fn',status='$_POST[select]' WHERE article_id='$_GET[editid]'";
 		 
		if($qsql = mysqli_query($con,$sql))
		{
			echo "<script>alert('Article record updated successfully...');</script>";
		}
		else
		{
			echo mysqli_error($con);
		}	
	}
	else
	{
	$sql ="INSERT INTO article(articlename,articlecontent,articleurl,pdf,status) values('$_POST[articlename]','$_POST[articlecontent]','$_POST[articleurl]','$fn','$_POST[select]')";
	if($qsql = mysqli_query($con,$sql))
	{
		echo "<script>alert('Article inserted successfully...');</script>";
	}
	else
	{
		echo mysqli_error($con);
	}
}
}
if(isset($_GET[editid]))
{
	$sql="SELECT * FROM article WHERE article_id='$_GET[editid]' ";
	$qsql = mysqli_query($con,$sql);
	$rsedit = mysqli_fetch_array($qsql);
	
}
?>

<div class="wrapper col2">
  <div id="breadcrumb">
    <ul>
      <li class="first"> Article </li></ul>
  </div>
</div>
<div class="wrapper col4">
  <div id="container">
    <h1>Add New Article</h1>
    <form method="post" action="" name="frmdept" onSubmit="return validateform()" enctype="multipart/form-data">
    <table width="418" border="3">
      <tbody>
        <tr>
          <td width="34%">Article Name</td>
          <td width="66%"><input type="text" name="articlename" id="articlename" placeholder=" Article Name"  value="<?php echo $rsedit[articlename]; ?>" /></td>
        </tr>
		<tr>
		<p>
			<td width="34%">Article Content</td>
            <td width="66%"><textarea name="articlecontent" id="articlecontent" value="<?php echo $rsedit[articlecontent]; ?>"cols="45%" rows="5%" required></textarea></td>
        </p>
		</tr>
        
        <tr> 
            <td  width="34%">Article Url</td> 
            <td width="66%"> <input type="text" name="articleurl" placeholder=" Article URL" value="<?php echo $rsedit[articleurl]; ?>"/>
		</tr>
 
        <tr> 
            <td>Select file</td> 
            <td><input type="file" name="dp"  /></td>
        </tr>


          </select></td>
        </tr>
		<tr>
          <td>Status</td>
          <td><select name="select" id="select">
            <option value="">Select</option>
            <?php
		  $arr= array("0 - UnPublished","1 - Published");
		  foreach($arr as $val)
		  {
			  if($val == $rsedit[status])
			  {
			  echo "<option value='$val' selected>$val</option>";
			  }
			  else
			  {
			  echo "<option value='$val'>$val</option>";
			  }
		  }
		  ?>
          </select></td>
        </tr>
        <tr>
          <td colspan="2" align="center"><input type="submit" name="submit" id="submit" value="Submit" /></td>
        </tr>
      </tbody>
    </table>
    </form>
    <p>&nbsp;</p>
  </div>
</div>
</div>
 <div class="clear"></div>
  </div>
</div>
<?php
include("footers.php");
?>
<script type="application/javascript">
var alphaExp = /^[a-zA-Z]+$/; //Variable to validate only alphabets
var alphaspaceExp = /^[a-zA-Z\s]+$/; //Variable to validate only alphabets and space
var numericExpression = /^[0-9]+$/; //Variable to validate only numbers
var alphanumericExp = /^[0-9a-zA-Z]+$/; //Variable to validate numbers and alphabets
var emailExp = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/; //Variable to validate Email ID 

function validateform()
{
	if(document.frmdept.articlename.value == "")
	{
		alert("article name should not be empty..");
		document.frmdept.articlename.focus();
		return false;
	}
	else if(!document.frmdept.articlename.value.match(alphanumericExp))
	{
		alert("article name not valid..");
		document.frmdept.articlename.focus();
		return false;
	}
	if(document.frmdept.articlecontent.value == "")
	{
		alert("article content should not be empty..");
		document.frmdept.articlecontent.focus();
		return false;
	}
	else if(!document.frmdept.articlecontent.value.match(alphaspaceExp))
	{
		alert("article not valid..");
		document.frmdept.articlecontent.focus();
		return false;
	}
	else if(document.frmdept.articleurl.value == "")
	{
		alert("article url should not be empty..");
		document.frmdept.articleurl.focus();
		return false;
	}
	else if(document.frmdept.dp.value == "")
	{
		alert("article document should not be empty..");
		document.frmdept.dp.focus();
		return false;
	}
	else if(document.frmdept.select.value == "" )
	{
		alert("Kindly select the status..");
		document.frmdept.select.focus();
		return false;
	}
	
	else
	{
		return true;
	}
}
</script>